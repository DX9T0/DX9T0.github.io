Randomiser Mod by DX9.


Made possible thanks to crustyrashky's mod loader (REQUIRED): https://github.com/crustyrashky/crus-modloader

This mod adds a button to the level select screen that starts a new run with random weapons, implants, map, difficulty and modifiers (punishment and chaos both have a 1 in 4 chance of being enabled).

There is also a 1% chance of making any individual enemy an extra target.

CAUTION: This mod does not check what you have and haven't unlocked. So...



		***DONT USE THIS MOD IF YOU CARE ABOUT SPOILERS OR UNLOCKING THINGS YOU HAVEN'T YET FOUND/PURCHASED THROUGH GAMEPLAY***



Also this mod shouldn't break anything save related but BACK UP YOUR SAVES JUST IN CASE!

Lastly, this mod is probably insanely unbalanced as a result of most things being up to chance. If you have any feedback or anything please get in touch.

Thanks for reading and good luck!