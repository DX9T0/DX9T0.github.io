
---Stutter Fix for Cruelty Squad---


Made by DX with much support from Teddybear082

Please DM me on Discord DX#2660 if you find any bugs, crashes or issues. Thank you!

Requires Cruelty Squad, Modloader (see quick start)

Some things to note:

- This mod will freeze the game for a while after a level loads, but it should get better the longer you play for.
- There will be minor visual weirdness during this freeze unlike in the vanilla game.
- I can't guarantee that this mod will alieviate stutters for everyone using it, but I have high confidence that it should. Feedback is welcome.

I hope it works as well for you as it does for me, please msg me about any issues, have fun :)

------------------------------------

Quick Start:

1. Install modloader: 
	- Download: https://github.com/disco0/crus-modloader/releases/tag/v0.2.2-beta
	- Installation instructions: https://github.com/disco0/crus-modloader/blob/v0.2.2-beta/README.md

2. Put the "Stutter Fix" folder inside your mods folder (C:\Users\*USERNAME*\AppData\Roaming\Godot\app_userdata\Cruelty Squad\mods\>Put it here<\)

------------------------------------

What is this Mod?

Cruelty Squad consistently stutters/hangs/freezes any time certain objects are rendered for the first time during play. This happens often at inconvenient times like when the player is in a firefight, 
since certain effects such as blood and bullet holes will hault the game until they can be displayed. A few of the larger maps will also cause the game to hang for a few seconds on lower end systems when the 
player looks in certain directions, which will almost always result in a painful freeze. The problem becomes less apparent the longer you play, as more objects get rendered for the first time and 
subsequently stop locking up the game. Although this issue lessens over time, there will still be occasional stutters that are essentially unavoidable.

The goal of this mod is to take all the stutters and microstutters, and bruteforce them out of the way the moment the level has loaded. This sometimes results in an extended wait time after the level loads,
where the game will hang for a few seconds as things get warmed up, but overall it results in a much more smooth framerate than in ordinary play. I have tested this mod across most of the maps in the game,
and I'm pretty sure that I have mitigated nearly every stutter causing element at this point. (There will probably still be very very occcasional stutters, its just the nature of the game and the engine)

Basically a graph that plots the stutters over time would go from this: ----^------^----^-^----^---^ to this : ^------------------

As stated above, I can't guarantee that your experience will be the same or that it will work for you, as everyone has different hardware. I'm reasonably confident that it will though.

How it works:

The mod "solves" the stutter issue in two ways:

- First, a camera is spawned which switches between 6 directions for each positive and negative direction of each axis, rendering the whole world brielfy before the level starts.
This means that every object in the level has essentially been "seen" once, preventing stutter from the player facing a previously unrenderered object.

- Next, the camera is made to face a collection of pretty much every stutter inducing material, mesh, decal/transparency in the game, creating one large stutter after the level loads. 
From the players perspective, the game hangs for a bit after the level is loaded, and there is some weirdness on the screen as things are prerendered, but then everything should return to normal 
and the game should be indistinguisable from vanilla crus, minus the annoying stutters. 


------------------------------------

Incompatibilities:

This mod overwrites Playercamera.tscn so any mod that touches that scene will not be compatible.

For modders:

The gdscript isn't compiled if you want to use it for anything. It's a pretty basic script. The "fakecache" scene is where the magic happens. 
Its mounted to the playercamera scene and gets queue_freed() after every instantiation of the player (level start)
It has pretty much every stutter causer in the game. If you want to use any of the files in the mod for anything, go for it :)